// server.js
const express = require('express');
const bodyParser = require('body-parser');
const signupHandler = require('./functions/signup').handler;
const loginHandler = require('./functions/login').handler;
const uploadImageHandler = require('./functions/uploadImage').handler;

const app = express();
const PORT = process.env.PORT || 5050;

app.use(bodyParser.json());

app.post('/signup', signupHandler);
app.post('/login', loginHandler);
app.post('/upload-image', uploadImageHandler);

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
