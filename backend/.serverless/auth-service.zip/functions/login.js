// functions/login.js

import { DynamoDBClient, GetItemCommand } from "@aws-sdk/client-dynamodb";
import bcrypt from 'bcrypt';

const dynamoDB = new DynamoDBClient({ region: "us-east-1" }); // Update to your region
const USERS_TABLE = "htran-table"; // Your DynamoDB table name

export const handler = async (event) => {
    const { email, password } = JSON.parse(event.body);

    const params = {
        TableName: USERS_TABLE,
        Key: { email },
    };

    try {
        const command = new GetItemCommand(params);
        const result = await dynamoDB.send(command);
        const user = result.Item;

        if (!user) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'User not found' }),
            };
        }

        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return {
                statusCode: 401,
                body: JSON.stringify({ error: 'Invalid password' }),
            };
        }

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'User logged in successfully!' }),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Error logging in user' }),
        };
    }
};
