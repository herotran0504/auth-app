// signup.js
import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
import bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';

const dynamoDB = new DynamoDBClient({ region: "us-east-1" }); // Update to your region
const USERS_TABLE = "htran-table"; // Your DynamoDB table name

export const handler = async (event) => {
    const { email, password, name, profileImage } = JSON.parse(event.body);

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    const params = {
        TableName: USERS_TABLE,
        Item: {
            email,
            password: hashedPassword,
            name,
            profileImage,
            id: uuidv4(), // Generate a unique ID
        },
    };

    try {
        const command = new PutItemCommand(params);
        await dynamoDB.send(command);
        return {
            statusCode: 201,
            body: JSON.stringify({ message: 'User signed up successfully!' }),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Error signing up user' }),
        };
    }
};
